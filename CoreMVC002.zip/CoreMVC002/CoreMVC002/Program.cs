﻿namespace CoreMVC002;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.
        builder.Services.AddControllersWithViews();

        // 1. 啟用 Session 快取與服務註冊 (免資料庫儲存猜測紀錄與題目)
        builder.Services.AddDistributedMemoryCache();
        builder.Services.AddSession(options =>
        {
            options.IdleTimeout = TimeSpan.FromMinutes(30); // Session 保留 30 分鐘
            options.Cookie.HttpOnly = true;
            options.Cookie.IsEssential = true;
        });

        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (!app.Environment.IsDevelopment())
        {
            app.UseExceptionHandler("/Home/Error");
        }
        app.UseStaticFiles();

        app.UseRouting();

        // 2. 啟用 Session 中介軟體 (注意：必須放在 UseRouting 之後、MapControllerRoute 之前)
        app.UseSession();

        app.UseAuthorization();

        app.MapControllerRoute(
            name: "default",
            pattern: "{controller=Home}/{action=Index}/{id?}");

        // 自訂 GuessNumber 路由對應到 GameController 的 Index
        app.MapControllerRoute(
            name: "GuessNumber",
            pattern: "GuessNumber",
            defaults: new { controller = "Game", action = "Index" });

        app.Run();
    }
}