﻿namespace CoreMVC002.Models
{
    public class XAXBEngine
    {
        public string SecretNumber { get; private set; }

        public XAXBEngine()
        {
            SecretNumber = GenerateSecretNumber();
        }

        // 用於從 Session 還原已建立題目的建構子
        public XAXBEngine(string secret)
        {
            SecretNumber = secret;
        }

        // 隨機產生 4 位互不重複的數字字串
        public static string GenerateSecretNumber()
        {
            Random rnd = new Random();
            List<int> digits = Enumerable.Range(0, 10).ToList();
            List<int> picked = new List<int>();

            for (int i = 0; i < 4; i++)
            {
                int index = rnd.Next(digits.Count);
                picked.Add(digits[index]);
                digits.RemoveAt(index);
            }
            return string.Join("", picked);
        }

        // 比對猜測數字，回傳 ?A?B
        public string CheckGuess(string guess)
        {
            int a = 0;
            int b = 0;

            for (int i = 0; i < 4; i++)
            {
                if (guess[i] == SecretNumber[i])
                {
                    a++;
                }
                else if (SecretNumber.Contains(guess[i]))
                {
                    b++;
                }
            }

            return $"{a}A{b}B";
        }
    }
}