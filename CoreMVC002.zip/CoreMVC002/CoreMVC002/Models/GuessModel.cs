﻿using System;
namespace CoreMVC002.Models
{
    public class GuessRecord
    {
        public int Turn { get; set; }           // 第幾次猜測
        public string GuessNumber { get; set; }  // 猜測的數字
        public string Result { get; set; }       // 例如：1A2B
    }

    public class GuessModel
    {
        public string? UserGuess { get; set; }               // 使用者當前輸入的數字
        public List<GuessRecord> History { get; set; } = new List<GuessRecord>(); // 歷次猜測紀錄
        public int GuessCount => History.Count;            // 累計猜測次數
        public bool IsGameOver { get; set; } = false;       // 是否已猜對結束 (4A0B)
        public string? ErrorMessage { get; set; }           // 輸入錯誤提示訊息
    }
}