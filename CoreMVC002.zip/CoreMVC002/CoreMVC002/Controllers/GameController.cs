﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreMVC002.Models;
using Microsoft.AspNetCore.Mvc;
using CoreMVC002.Models;
using System.Text.Json;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CoreMVC002.Controllers
{
    public class GameController : Controller
    {
        private const string SessionSecretKey = "_SecretNumber";
        private const string SessionHistoryKey = "_GuessHistory";

        // GET: /Game 或 /Game/Index
        public IActionResult Index()
        {
            var model = InitOrGetGame();
            return View(model);
        }

        // POST: /Game/Guess
        [HttpPost]
        public IActionResult Guess(string userGuess)
        {
            var model = InitOrGetGame();

            // 檢查使用者輸入 (需為 4 位且不重複的數字)
            if (string.IsNullOrWhiteSpace(userGuess) || userGuess.Length != 4 || !userGuess.All(char.IsDigit) || userGuess.Distinct().Count() != 4)
            {
                model.ErrorMessage = "請輸入 4 個不重複的數字！";
                return View("Index", model);
            }

            string secret = HttpContext.Session.GetString(SessionSecretKey)!;
            XAXBEngine engine = new XAXBEngine(secret);

            string result = engine.CheckGuess(userGuess);

            // 加入歷史紀錄
            model.History.Add(new GuessRecord
            {
                Turn = model.History.Count + 1,
                GuessNumber = userGuess,
                Result = result
            });

            // 判斷是否猜對 (4A0B)
            if (result == "4A0B")
            {
                model.IsGameOver = true;
            }

            // 更新 Session
            SaveHistory(model.History);

            return View("Index", model);
        }

        // 重新開始新的一局
        public IActionResult Reset()
        {
            HttpContext.Session.Remove(SessionSecretKey);
            HttpContext.Session.Remove(SessionHistoryKey);
            return RedirectToAction("Index");
        }

        private GuessModel InitOrGetGame()
        {
            string? secret = HttpContext.Session.GetString(SessionSecretKey);
            if (string.IsNullOrEmpty(secret))
            {
                secret = XAXBEngine.GenerateSecretNumber();
                HttpContext.Session.SetString(SessionSecretKey, secret);
            }

            var model = new GuessModel();
            string? historyJson = HttpContext.Session.GetString(SessionHistoryKey);
            if (!string.IsNullOrEmpty(historyJson))
            {
                model.History = JsonSerializer.Deserialize<List<GuessRecord>>(historyJson) ?? new List<GuessRecord>();
            }

            if (model.History.Any(h => h.Result == "4A0B"))
            {
                model.IsGameOver = true;
            }

            return model;
        }

        private void SaveHistory(List<GuessRecord> history)
        {
            HttpContext.Session.SetString(SessionHistoryKey, JsonSerializer.Serialize(history));
        }
    }
}

